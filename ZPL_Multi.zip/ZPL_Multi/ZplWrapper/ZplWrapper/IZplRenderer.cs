﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ZplWrapper
{
    public interface IZplRenderer
    {
        byte[] RenderToPng(string zpl, int dpi = 203);
    }
}
