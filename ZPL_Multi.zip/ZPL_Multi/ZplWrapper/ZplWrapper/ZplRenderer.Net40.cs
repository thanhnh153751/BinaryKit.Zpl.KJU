﻿#if NET40
using System;

namespace ZplWrapper
{
    public class ZplRenderer : IZplRenderer
    {
        public byte[] RenderToPng(string zpl, int dpi = 203)
        {
            throw new NotSupportedException("Rendering not supported on .NET Framework 4.0. Use bridge process.");
        }
    }
}
#endif
