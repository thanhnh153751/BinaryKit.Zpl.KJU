﻿#if NET8_0
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using BinaryKits.Zpl.Label;
using BinaryKits.Zpl.Viewer;

namespace ZplWrapper
{
    public class ZplRenderer : IZplRenderer
    {
        private ZplRenderOptions zplRenderOptions;

        public ZplRenderer(ZplRenderOptions zplRenderOptions)
        {
            this.zplRenderOptions = zplRenderOptions;
        }

        public byte[] RenderToPng(string zpl, int dpi = 203)
        {
            var drawer = new ZplRenderer(new ZplRenderOptions
            {
                DotsPerMillimeter = dpi / 25.4
            });

            var bitmap = drawer.Render(zpl);

            using (var ms = new MemoryStream())
            {
                bitmap.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }
    }
}
#endif
